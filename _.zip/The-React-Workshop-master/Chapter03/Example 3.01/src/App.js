import React from 'react';
import logo from './logo.svg';
import './App.css';

const App = () => (
    <div className="App">
        <button>Click me to show the rest!</button>
        <div>
            I am the content that should be hidden by default!
        </div>
    </div>
  );

export default App;
