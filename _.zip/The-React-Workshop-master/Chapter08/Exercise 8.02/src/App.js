import React from 'react';
import {ControlledForm} from './ControlledForm';
import './App.css';

function App() {
  return (
  <div className="App">
  <ControlledForm />
  </div>
  );
}
export default App;

